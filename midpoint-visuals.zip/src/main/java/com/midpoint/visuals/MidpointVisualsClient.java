package com.midpoint.visuals;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.cosmetics.CosmeticsRenderer;
import com.midpoint.visuals.gui.MidpointGuiScreen;
import com.midpoint.visuals.gui.MidpointKeybinds;
import com.midpoint.visuals.particle.ParticleRegistry;
import com.midpoint.visuals.render.FogBlurHandler;
import com.midpoint.visuals.render.QuantumLinkRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;

public class MidpointVisualsClient implements ClientModInitializer {
    public static final String MOD_ID = "midpoint_visuals";

    @Override
    public void onInitializeClient() {
        ConfigManager.load();

        ParticleRegistry.register();
        MidpointKeybinds.register();

        WorldRenderEvents.AFTER_ENTITIES.register(QuantumLinkRenderer::render);
        WorldRenderEvents.START.register(FogBlurHandler::onWorldRenderStart);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MidpointKeybinds.tick(client);
            QuantumLinkRenderer.tick();
            CosmeticsRenderer.tick(client);
        });
    }

    public static void openMenu() {
        MinecraftClient.getInstance().setScreen(new MidpointGuiScreen(null));
    }
}
