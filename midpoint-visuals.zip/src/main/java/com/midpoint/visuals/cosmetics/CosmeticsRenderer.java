package com.midpoint.visuals.cosmetics;

import com.midpoint.visuals.config.ConfigManager;
import net.minecraft.client.MinecraftClient;

/**
 * Module 6: Cosmetics.
 *
 * Framework for rendering 3D cosmetics above a player's head (first target
 * model: "monkey on a mountain"). Auto-disables itself when FPS drops below
 * a configurable threshold so cosmetic rendering never becomes the reason a
 * mobile device starts stuttering.
 */
public final class CosmeticsRenderer {
    private static boolean autoDisabledByLag = false;

    private CosmeticsRenderer() {
    }

    public static void tick(MinecraftClient client) {
        var cfg = ConfigManager.get();
        if (!cfg.cosmeticsEnabled) {
            autoDisabledByLag = false;
            return;
        }

        if (!cfg.cosmeticsAutoDisableOnLag) {
            autoDisabledByLag = false;
            return;
        }

        int fps = client.getCurrentFps();
        if (fps > 0 && fps < cfg.cosmeticsFpsThreshold) {
            autoDisabledByLag = true;
        } else if (fps >= cfg.cosmeticsFpsThreshold + 10) {
            // Small hysteresis band so it doesn't flicker on/off at the threshold.
            autoDisabledByLag = false;
        }
    }

    public static boolean shouldRender() {
        return ConfigManager.get().cosmeticsEnabled && !autoDisabledByLag;
    }

    /**
     * Placeholder entry point for the actual cosmetic model render call.
     * Wire this into a FeatureRenderer registered on PlayerEntityRenderer
     * (via a client mixin) once the "monkey on a mountain" model/texture
     * assets exist under assets/midpoint_visuals/models/cosmetics/.
     */
    public static void renderCosmetic(String cosmeticId) {
        if (!shouldRender()) {
            return;
        }
        // TODO: FeatureRenderer draw call for `cosmeticId`.
    }
}
