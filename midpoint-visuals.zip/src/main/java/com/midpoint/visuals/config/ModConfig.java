package com.midpoint.visuals.config;

/**
 * Plain data holder serialized to config/midpoint_visuals.json via Gson.
 * ALL modules default to OFF / false per spec - nothing is active on first launch.
 */
public class ModConfig {

    // ---- Module 1: Realistic Spirits & Cubes ----
    public ModuleState spiritsAndCubesState = ModuleState.OFF;
    public int spiritColor = 0xAA88FF;
    public int cubeColor = 0xFFFFFF;

    // ---- Module 2: Quantum Link + Reach Indicator ----
    public ModuleState quantumLinkState = ModuleState.OFF;
    public int quantumLineColor = 0x00FFFF;
    public int quantumTextColor = 0xFFFFFF;

    // ---- Module 3: HitColor ----
    public ModuleState hitColorState = ModuleState.OFF;
    /** Used when hitColorState == ON. RANDOM cycles between soft presets at runtime. */
    public int hitColorCustom = 0xFFF6B8;

    // ---- Module 4: PvP & CPvP Anti-Lag ----
    public boolean antiLagEnabled = false;
    public boolean disableFlash = false;
    public boolean disableCrystalParticles = false;
    public boolean disableAnchorParticles = false;
    public boolean optimizeEnderPearl = false;

    // ---- Module 5: Fog & Blur ----
    public ModuleState fogState = ModuleState.OFF;
    public int fogPreset = 0; // index into FogBlurHandler presets (0-3)
    public ModuleState motionBlurState = ModuleState.OFF;
    public float motionBlurStrength = 0.35f;

    // ---- Module 6: Cosmetics ----
    public boolean cosmeticsEnabled = false;
    public String selectedCosmetic = "monkey_on_mountain";
    public boolean cosmeticsAutoDisableOnLag = true;
    public int cosmeticsFpsThreshold = 40;

    // ---- Module 7: Utility ----
    public boolean utilityEnabled = false;
    public String quickChatMessage = "gg";

    // ---- Keybinds (GLFW key codes) ----
    public int menuKey = 344;       // GLFW_KEY_RIGHT_SHIFT
    public int quickChatKey = 66;   // GLFW_KEY_B
}
