package com.midpoint.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Loads/saves the mod configuration to <run>/config/midpoint_visuals.json.
 * Kept as a static singleton so every module can cheaply read the current
 * state without passing config references through the whole call chain -
 * important on the hot render/tick path where allocations must stay minimal.
 */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("midpoint_visuals.json");

    private static ModConfig config;

    private ConfigManager() {
    }

    public static ModConfig get() {
        if (config == null) {
            load();
        }
        return config;
    }

    public static void load() {
        ModConfig loaded = null;
        if (Files.exists(CONFIG_PATH)) {
            try (var reader = Files.newBufferedReader(CONFIG_PATH)) {
                loaded = GSON.fromJson(reader, ModConfig.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        config = loaded != null ? loaded : new ModConfig();
        save();
    }

    public static void save() {
        try {
            if (CONFIG_PATH.getParent() != null) {
                Files.createDirectories(CONFIG_PATH.getParent());
            }
            try (var writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(config, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
