package com.midpoint.visuals.config;

/**
 * Every visual module in Midpoint Visuals supports exactly three states:
 * OFF     - module fully disabled, zero overhead.
 * ON      - module active with a fixed effect/color.
 * RANDOM  - module active, effect/color randomized on each trigger.
 */
public enum ModuleState {
    OFF,
    ON,
    RANDOM;

    public ModuleState next() {
        return values()[(this.ordinal() + 1) % values().length];
    }
}
