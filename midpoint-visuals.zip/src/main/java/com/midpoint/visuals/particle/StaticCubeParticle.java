package com.midpoint.visuals.particle;

import com.midpoint.visuals.config.ConfigManager;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.SimpleParticleType;

/**
 * Small colored cube that freezes rigidly in the air at the hit location
 * (no gravity, no velocity, no collision checks) and fades out.
 * Deliberately as cheap as possible per-tick since these can spawn in bursts.
 */
public class StaticCubeParticle extends SpriteBillboardParticle {

    protected StaticCubeParticle(ClientWorld world, double x, double y, double z, SpriteProvider spriteProvider) {
        super(world, x, y, z, 0, 0, 0);
        this.velocityX = 0;
        this.velocityY = 0;
        this.velocityZ = 0;
        this.gravityStrength = 0f;
        this.maxAge = 60; // 3s
        this.scale = 0.08f;
        this.collidesWithWorld = false;

        int color = ConfigManager.get().cubeColor;
        this.red = ((color >> 16) & 0xFF) / 255f;
        this.green = ((color >> 8) & 0xFF) / 255f;
        this.blue = (color & 0xFF) / 255f;

        this.setSpriteForAge(spriteProvider);
    }

    @Override
    public void tick() {
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;

        if (this.age++ >= this.maxAge) {
            this.markDead();
            return;
        }

        this.alpha = 1.0f - (float) this.age / this.maxAge;
        // Intentionally: no position update -> particle stays rigidly frozen in place.
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_OPAQUE;
    }

    public static class Factory implements ParticleFactory<SimpleParticleType> {
        private final SpriteProvider spriteProvider;

        public Factory(SpriteProvider spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientWorld world,
                                        double x, double y, double z, double vx, double vy, double vz) {
            return new StaticCubeParticle(world, x, y, z, this.spriteProvider);
        }
    }
}
