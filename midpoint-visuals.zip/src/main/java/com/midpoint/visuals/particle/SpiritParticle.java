package com.midpoint.visuals.particle;

import com.midpoint.visuals.config.ConfigManager;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.util.math.MathHelper;

/**
 * Slow, smooth "spirit" that orbits around a damaged entity and fades out
 * after ~10 seconds (200 ticks) if no further damage refreshes it.
 */
public class SpiritParticle extends SpriteBillboardParticle {
    private final SpriteProvider spriteProvider;
    private final double centerX;
    private final double centerY;
    private final double centerZ;
    private final double radius;
    private double angle;

    protected SpiritParticle(ClientWorld world, double x, double y, double z, SpriteProvider spriteProvider) {
        super(world, x, y, z, 0, 0, 0);
        this.spriteProvider = spriteProvider;
        this.centerX = x;
        this.centerY = y;
        this.centerZ = z;
        this.radius = 0.4 + this.random.nextDouble() * 0.35;
        this.angle = this.random.nextDouble() * Math.PI * 2;
        this.maxAge = 200; // 10s at 20 tps
        this.scale = 0.11f + this.random.nextFloat() * 0.05f;
        this.collidesWithWorld = false;

        int color = ConfigManager.get().spiritColor;
        this.red = ((color >> 16) & 0xFF) / 255f;
        this.green = ((color >> 8) & 0xFF) / 255f;
        this.blue = (color & 0xFF) / 255f;

        this.setSpriteForAge(spriteProvider);
    }

    @Override
    public void tick() {
        this.prevPosX = this.x;
        this.prevPosY = this.y;
        this.prevPosZ = this.z;

        if (this.age++ >= this.maxAge) {
            this.markDead();
            return;
        }

        // Cheap circular orbit - no physics/collision checks, keeps tick() O(1)
        this.angle += 0.055;
        this.x = this.centerX + Math.cos(this.angle) * this.radius;
        this.z = this.centerZ + Math.sin(this.angle) * this.radius;
        this.y = this.centerY + Math.sin(this.age * 0.05) * 0.25;

        this.setSpriteForAge(this.spriteProvider);
        this.alpha = MathHelper.clamp(1.0f - (float) this.age / this.maxAge, 0f, 1f);
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Factory implements ParticleFactory<SimpleParticleType> {
        private final SpriteProvider spriteProvider;

        public Factory(SpriteProvider spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientWorld world,
                                        double x, double y, double z, double vx, double vy, double vz) {
            return new SpiritParticle(world, x, y, z, this.spriteProvider);
        }
    }
}
