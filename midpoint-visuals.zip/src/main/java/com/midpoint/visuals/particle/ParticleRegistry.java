package com.midpoint.visuals.particle;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.client.particle.ParticleFactoryRegistry;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * Custom particle types for Module 1 (Realistic Spirits & Cubes).
 *
 * Performance note: both particles reuse vanilla's built-in particle
 * rendering pipeline (SpriteBillboardParticle -> ParticleTextureSheet),
 * which already batches all particles sharing a sheet into a handful of
 * draw calls per frame. This gives us "instancing-like" behaviour for free
 * without a custom renderer, which is what keeps this cheap on mobile GPUs
 * (Adreno/Mali) - the expensive part is usually per-particle tick logic,
 * not draw calls, so both particle classes below keep tick() minimal.
 */
public final class ParticleRegistry {
    public static final SimpleParticleType SPIRIT_PARTICLE = FabricParticleTypes.simple();
    public static final SimpleParticleType STATIC_CUBE_PARTICLE = FabricParticleTypes.simple();

    private ParticleRegistry() {
    }

    public static void register() {
        Registry.register(Registries.PARTICLE_TYPE,
                Identifier.of("midpoint_visuals", "spirit_particle"), SPIRIT_PARTICLE);
        Registry.register(Registries.PARTICLE_TYPE,
                Identifier.of("midpoint_visuals", "static_cube_particle"), STATIC_CUBE_PARTICLE);

        ParticleFactoryRegistry.getInstance().register(SPIRIT_PARTICLE, SpiritParticle.Factory::new);
        ParticleFactoryRegistry.getInstance().register(STATIC_CUBE_PARTICLE, StaticCubeParticle.Factory::new);
    }
}
