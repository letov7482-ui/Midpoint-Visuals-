package com.midpoint.visuals.render;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModuleState;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;

/**
 * Module 5: Fog & Blur.
 *
 * Fog color presets are applied through {@code FogRenderMixin} (see the
 * mixin package) so the actual color swap happens inside vanilla's own fog
 * pass - no extra draw calls. Motion blur is intentionally left as a
 * documented scaffold: a correct mobile-friendly implementation needs a
 * custom lightweight PostEffectProcessor shader, which is out of scope for
 * a first-pass framework but the hook points below are where it plugs in.
 */
public final class FogBlurHandler {

    private static final int[] FOG_PRESETS = {
            0x55C1FF, // preset 0: soft blue
            0xFF9E80, // preset 1: warm sunset
            0x8B5CF6, // preset 2: purple haze
            0x1A1A1A  // preset 3: dark ash
    };

    private FogBlurHandler() {
    }

    public static int getPresetColor(int index) {
        if (index < 0 || index >= FOG_PRESETS.length) {
            return FOG_PRESETS[0];
        }
        return FOG_PRESETS[index];
    }

    public static boolean isFogActive() {
        return ConfigManager.get().fogState != ModuleState.OFF;
    }

    /**
     * Called once per frame from WorldRenderEvents.START. Reserved for
     * driving the motion-blur post-process pass once implemented; kept as a
     * no-op while the module is OFF so it costs nothing on mobile GPUs.
     */
    public static void onWorldRenderStart(WorldRenderContext context) {
        ModuleState blurState = ConfigManager.get().motionBlurState;
        if (blurState == ModuleState.OFF) {
            return;
        }
        // TODO: dispatch a custom PostEffectProcessor
        // (assets/midpoint_visuals/shaders/post/motion_blur.json) blended
        // with the previous frame buffer at ConfigManager.get().motionBlurStrength.
    }
}
