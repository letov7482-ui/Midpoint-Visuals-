package com.midpoint.visuals.render;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModuleState;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Module 2: Quantum Link + Reach Indicator.
 *
 * Draws a thin neon line between attacker and target for ~0.2s (4 ticks) on
 * every hit, plus a billboarded distance label at the line's midpoint.
 * Line color and text color are independently configurable, including
 * pure black, via ConfigManager.
 */
public final class QuantumLinkRenderer {
    private static final int DURATION_TICKS = 4; // ~0.2s @ 20 tps

    private static Entity target;
    private static Vec3d attackerPos;
    private static Vec3d targetPos;
    private static int ticksLeft;

    private QuantumLinkRenderer() {
    }

    /** Call from the attack-entity mixin hook whenever the local player hits something. */
    public static void trigger(PlayerEntity attacker, LivingEntity hitEntity) {
        ModuleState state = ConfigManager.get().quantumLinkState;
        if (state == ModuleState.OFF) return;

        attackerPos = attacker.getCameraPosVec(1.0f);
        targetPos = hitEntity.getPos().add(0, hitEntity.getHeight() / 2.0, 0);
        target = hitEntity;
        ticksLeft = DURATION_TICKS;
    }

    /** Call once per client tick to expire the effect. */
    public static void tick() {
        if (ticksLeft > 0) {
            ticksLeft--;
        }
    }

    /** Call from WorldRenderEvents.AFTER_ENTITIES. */
    public static void render(WorldRenderContext context) {
        if (ticksLeft <= 0 || target == null || attackerPos == null || targetPos == null) {
            return;
        }
        if (!target.isAlive()) {
            return;
        }

        var cfg = ConfigManager.get();
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;
        Vec3d camPos = context.camera().getPos();

        MinecraftClient client = MinecraftClient.getInstance();
        VertexConsumerProvider.Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();

        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);

        drawLine(matrices, consumers, attackerPos, targetPos, cfg.quantumLineColor);
        drawDistanceLabel(matrices, consumers, client, attackerPos, targetPos, cfg.quantumTextColor);

        consumers.draw();
        matrices.pop();
    }

    private static void drawLine(MatrixStack matrices, VertexConsumerProvider consumers,
                                  Vec3d from, Vec3d to, int color) {
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getLineStrip());
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        buffer.vertex(matrix, (float) from.x, (float) from.y, (float) from.z)
                .color(r, g, b, 0.9f)
                .normal(matrices.peek(), 0f, 1f, 0f);
        buffer.vertex(matrix, (float) to.x, (float) to.y, (float) to.z)
                .color(r, g, b, 0.9f)
                .normal(matrices.peek(), 0f, 1f, 0f);
    }

    private static void drawDistanceLabel(MatrixStack matrices, VertexConsumerProvider consumers,
                                           MinecraftClient client, Vec3d from, Vec3d to, int textColor) {
        Vec3d mid = from.add(to).multiply(0.5);
        double distance = from.distanceTo(to);
        String label = String.format("%.2fm", distance);

        matrices.push();
        matrices.translate(mid.x, mid.y, mid.z);
        // Billboard: cancel out the world rotation so text always faces the camera.
        matrices.multiply(client.gameRenderer.getCamera().getRotation());
        matrices.scale(-0.025f, -0.025f, 0.025f);

        TextRenderer textRenderer = client.textRenderer;
        int textWidth = textRenderer.getWidth(label);
        Matrix4f textMatrix = matrices.peek().getPositionMatrix();

        // Soft shadow behind the label so it never blends into similarly-lit blocks.
        textRenderer.draw(label, -textWidth / 2f + 1f, 1f, 0x66000000, false,
                textMatrix, consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        // Foreground label
        textRenderer.draw(label, -textWidth / 2f, 0f, textColor, false,
                textMatrix, consumers, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);

        matrices.pop();
    }
}
