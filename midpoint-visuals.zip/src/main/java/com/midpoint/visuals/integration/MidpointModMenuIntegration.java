package com.midpoint.visuals.integration;

import com.midpoint.visuals.gui.MidpointGuiScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public class MidpointModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return MidpointGuiScreen::new;
    }
}
