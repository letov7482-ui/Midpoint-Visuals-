package com.midpoint.visuals.gui;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.config.ModuleState;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Pure vanilla-render GUI (no third-party UI libraries), styled deep matte
 * black with large, touch-friendly buttons for mobile Java launchers
 * (Pojav, Zalith, FCL, Mojo). Opened via ModMenu or the configurable
 * keybind (default RSHIFT).
 */
public class MidpointGuiScreen extends Screen {
    private static final int BG_COLOR = 0xFF0D0D0D;
    private static final int TITLE_COLOR = 0xFF9D7CFF;

    private final Screen parent;
    private final List<ModuleRow> rows = new ArrayList<>();

    public MidpointGuiScreen(Screen parent) {
        super(Text.literal("Midpoint Visuals"));
        this.parent = parent;
    }

    private record ModuleRow(String title, Supplier<ModuleState> getter, Consumer<ModuleState> setter) {
    }

    @Override
    protected void init() {
        ModConfig cfg = ConfigManager.get();
        rows.clear();
        rows.add(new ModuleRow("Spirits & Cubes", () -> cfg.spiritsAndCubesState, s -> cfg.spiritsAndCubesState = s));
        rows.add(new ModuleRow("Quantum Link", () -> cfg.quantumLinkState, s -> cfg.quantumLinkState = s));
        rows.add(new ModuleRow("HitColor", () -> cfg.hitColorState, s -> cfg.hitColorState = s));
        rows.add(new ModuleRow("Fog", () -> cfg.fogState, s -> cfg.fogState = s));
        rows.add(new ModuleRow("Motion Blur", () -> cfg.motionBlurState, s -> cfg.motionBlurState = s));

        int buttonHeight = 40; // large, touch-friendly
        int spacing = 8;
        int buttonWidth = Math.min(420, this.width - 40);
        int x = (this.width - buttonWidth) / 2;
        int y = 56;

        for (ModuleRow row : rows) {
            final int fy = y;
            this.addDrawableChild(ButtonWidget.builder(stateLabel(row.title(), row.getter().get()), btn -> {
                        ModuleState next = row.getter().get().next();
                        row.setter().accept(next);
                        btn.setMessage(stateLabel(row.title(), next));
                        ConfigManager.save();
                    })
                    .dimensions(x, fy, buttonWidth, buttonHeight)
                    .build());
            y += buttonHeight + spacing;
        }

        y += 10;
        y = addToggle(x, y, buttonWidth, buttonHeight, "Anti-Lag (PvP/CPvP)", () -> cfg.antiLagEnabled, v -> {
            cfg.antiLagEnabled = v;
            cfg.disableFlash = v;
            cfg.disableCrystalParticles = v;
            cfg.disableAnchorParticles = v;
            cfg.optimizeEnderPearl = v;
        });
        y = addToggle(x, y, buttonWidth, buttonHeight, "Cosmetics", () -> cfg.cosmeticsEnabled, v -> cfg.cosmeticsEnabled = v);
        y = addToggle(x, y, buttonWidth, buttonHeight, "Utility (quick-chat)", () -> cfg.utilityEnabled, v -> cfg.utilityEnabled = v);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), btn -> this.close())
                .dimensions(x, this.height - 50, buttonWidth, 32)
                .build());
    }

    private int addToggle(int x, int y, int width, int height, String title,
                           Supplier<Boolean> getter, Consumer<Boolean> setter) {
        this.addDrawableChild(ButtonWidget.builder(boolLabel(title, getter.get()), btn -> {
                    boolean next = !getter.get();
                    setter.accept(next);
                    btn.setMessage(boolLabel(title, next));
                    ConfigManager.save();
                })
                .dimensions(x, y, width, height)
                .build());
        return y + height + 8;
    }

    private Text stateLabel(String title, ModuleState state) {
        String stateStr = switch (state) {
            case OFF -> "OFF";
            case ON -> "ON";
            case RANDOM -> "RANDOM";
        };
        return Text.literal(title + ":  " + stateStr);
    }

    private Text boolLabel(String title, boolean value) {
        return Text.literal(title + ":  " + (value ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, BG_COLOR);
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, "MIDPOINT VISUALS", this.width / 2, 20, TITLE_COLOR);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPauseGame() {
        return false;
    }
}
