package com.midpoint.visuals.gui;

import com.midpoint.visuals.MidpointVisualsClient;
import com.midpoint.visuals.config.ConfigManager;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/**
 * Module 7 (Utility) key handling + the global menu-open keybind.
 * Defaults: RSHIFT opens the menu, B sends the configured quick-chat message.
 */
public final class MidpointKeybinds {
    public static KeyBinding openMenuKey;
    public static KeyBinding quickChatKey;

    private MidpointKeybinds() {
    }

    public static void register() {
        var cfg = ConfigManager.get();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.midpoint_visuals.open_menu",
                InputUtil.Type.KEYSYM,
                cfg.menuKey,
                "category.midpoint_visuals.main"
        ));

        quickChatKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.midpoint_visuals.quick_chat",
                InputUtil.Type.KEYSYM,
                cfg.quickChatKey,
                "category.midpoint_visuals.main"
        ));
    }

    public static void tick(MinecraftClient client) {
        if (client.player == null) {
            return;
        }

        while (openMenuKey.wasPressed()) {
            MidpointVisualsClient.openMenu();
        }

        var cfg = ConfigManager.get();
        while (quickChatKey.wasPressed()) {
            if (cfg.utilityEnabled && client.player.networkHandler != null) {
                client.player.networkHandler.sendChatMessage(cfg.quickChatMessage);
            }
        }
    }
}
