package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModuleState;
import com.midpoint.visuals.particle.ParticleRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Module 1: Realistic Spirits & Cubes.
 * Fires whenever a living entity actually takes damage on the client
 * (client-side prediction / remote entity damage animation), spawning the
 * orbiting spirit particles + frozen hit cubes at the entity's position.
 */
@Mixin(LivingEntity.class)
public abstract class DamageParticleMixin {

    @Inject(method = "damage", at = @At("RETURN"))
    private void midpointVisuals$onDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (!Boolean.TRUE.equals(cir.getReturnValue())) {
            return;
        }

        ModuleState state = ConfigManager.get().spiritsAndCubesState;
        if (state == ModuleState.OFF) {
            return;
        }

        LivingEntity self = (LivingEntity) (Object) this;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.world != self.getWorld()) {
            return;
        }

        double x = self.getX();
        double y = self.getBodyY(0.5);
        double z = self.getZ();

        for (int i = 0; i < 6; i++) {
            client.world.addParticle(ParticleRegistry.SPIRIT_PARTICLE, x, y, z, 0, 0, 0);
        }
        for (int i = 0; i < 3; i++) {
            double ox = (client.world.random.nextDouble() - 0.5) * 0.6;
            double oy = client.world.random.nextDouble() * 0.6;
            double oz = (client.world.random.nextDouble() - 0.5) * 0.6;
            client.world.addParticle(ParticleRegistry.STATIC_CUBE_PARTICLE, x + ox, y + oy, z + oz, 0, 0, 0);
        }
    }
}
