package com.midpoint.visuals.mixin;

import net.minecraft.client.render.OverlayTexture;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Module 3: HitColor - scaffold.
 *
 * Vanilla's red damage tint is baked into the small gradient texture that
 * {@link OverlayTexture} generates on startup, rather than being a simple
 * "color" field. A correct implementation intercepts that texture
 * generation (or the whiteOverlay/hurtOverlay UV lookup, depending on
 * mapping/version) and substitutes ConfigManager.get().hitColorCustom when
 * hitColorState != OFF.
 *
 * NOTE: exact field/method names inside OverlayTexture can shift between
 * Minecraft snapshots - verify against the mapped 1.21.4 Yarn sources
 * before filling in the injector below, since this is version-sensitive
 * low-level rendering code that must match the exact class layout to compile.
 */
@Mixin(OverlayTexture.class)
public class HitColorMixin {
    // Scaffold only - see class javadoc.
}
