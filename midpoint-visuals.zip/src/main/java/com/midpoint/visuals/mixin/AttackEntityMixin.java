package com.midpoint.visuals.mixin;

import com.midpoint.visuals.render.QuantumLinkRenderer;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Module 2: Quantum Link + Reach Indicator.
 * Triggers the line + distance label whenever the local player attacks a
 * living entity.
 */
@Mixin(ClientPlayerInteractionManager.class)
public class AttackEntityMixin {

    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void midpointVisuals$onAttack(ClientPlayerEntity player, Entity target, CallbackInfo ci) {
        if (target instanceof LivingEntity livingTarget) {
            QuantumLinkRenderer.trigger(player, livingTarget);
        }
    }
}
