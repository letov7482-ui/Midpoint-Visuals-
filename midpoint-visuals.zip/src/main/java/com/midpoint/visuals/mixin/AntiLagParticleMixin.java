package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Module 4: PvP & CPvP Anti-Lag.
 *
 * A single, generic hook into ClientWorld#addParticle is enough to cover
 * End Crystal explosions, Respawn Anchor explosions (both spawn FLASH /
 * EXPLOSION / EXPLOSION_EMITTER particles) and the Ender Pearl's PORTAL
 * trail, without needing separate mixins per entity type. This keeps the
 * anti-lag path a single cheap branch instead of several render-hook
 * mixins, which matters more on low-end mobile GPUs than draw-call count
 * for these effects.
 */
@Mixin(ClientWorld.class)
public class AntiLagParticleMixin {

    @Inject(
            method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void midpointVisuals$filterParticles(ParticleEffect parameters, double x, double y, double z,
                                                  double vx, double vy, double vz, CallbackInfo ci) {
        var cfg = ConfigManager.get();

        if (cfg.antiLagEnabled) {
            if (parameters == ParticleTypes.FLASH
                    || parameters == ParticleTypes.EXPLOSION_EMITTER
                    || parameters == ParticleTypes.EXPLOSION) {
                ci.cancel();
                return;
            }
        }

        if (cfg.optimizeEnderPearl && parameters == ParticleTypes.PORTAL) {
            ci.cancel();
        }
    }
}
