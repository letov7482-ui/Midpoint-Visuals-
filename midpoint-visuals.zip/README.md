<p align="center">
  <img src="docs/logo.svg" alt="Midpoint Visuals" width="620">
</p>

<p align="center">
  <b>High-performance client-side PvP visuals for Fabric 1.21.4</b><br>
  Built for stable FPS on PC <i>and</i> mobile Java launchers.
</p>

---

## О моде

**Midpoint Visuals** (`midpoint_visuals`) — клиентский Fabric-мод для Minecraft **1.21.4**,
сфокусированный на визуальных PvP-эффектах при сохранении максимальной производительности,
в том числе на слабых мобильных GPU (Adreno / Mali) в лаунчерах Pojav, Zalith, FCL, Mojo и аналогичных.

**Все модули по умолчанию выключены.** Каждый визуальный модуль поддерживает три состояния:

| Состояние | Значение |
|---|---|
| `OFF`    | модуль полностью выключен, нулевые накладные расходы |
| `ON`     | модуль включён с фиксированным эффектом/цветом |
| `RANDOM` | модуль включён, эффект/цвет выбирается случайно при срабатывании |

Меню открывается по кнопке **RSHIFT** (настраивается) или через **ModMenu**.

## Модули

1. **Реалистичные Духи и Кубики** — плавные кружащиеся частицы вокруг раненого врага (исчезают
   через 10с без урона) + статичные цветные кубики на месте удара. Рендер использует встроенный
   батчинг вершин Minecraft (`ParticleTextureSheet`) — все частицы одного листа рисуются за
   считанные draw call'ы.
2. **Quantum Link + Reach Indicator** — неоновая линия между атакующим и целью на 0.2с с
   billboard-текстом точной дистанции ("2.84m") и мягкой тенью. Цвет линии и цвет текста
   настраиваются независимо (включая чёрный) через `ConfigManager`.
3. **HitColor** — замена стандартного красного цвета получения урона на мягкий белый/жёлтый/кастомный.
4. **PvP & CPvP Anti-Lag** — отключение вспышек и тяжёлых частиц Крипта Энда / Якоря,
   оптимизация рендера жемчуга Энда.
5. **Fog & Blur** — 3-4 пресета цветного тумана + настраиваемый Motion Blur.
6. **Cosmetics** — система 3D-косметики над головой игрока (заготовка "Обезьяна на горе") с
   авто-отключением при просадках FPS.
7. **Utility** — бинды клавиш, по умолчанию `B` отправляет `"gg"` в чат.

> ⚠️ Модули 3 (`HitColor`) и 5 (`Fog`) содержат Java-класс миксина и подробный комментарий,
> но требуют финальной привязки к конкретному методу `OverlayTexture` / `BackgroundRenderer`
> — это низкоуровневый рендер-код, чувствительный к точным маппингам версии, поэтому оставлен
> как явно задокументированный каркас (см. `HitColorMixin.java`, `FogRenderMixin.java`).

## Сборка

Требуется JDK 21.

```bash
gradle build
```

Готовый `.jar` появится в `build/libs/`. GitHub Actions (`.github/workflows/build.yml`)
автоматически собирает мод при каждом push/PR в `main` и прикладывает `.jar` как артефакт сборки.

> В репозитории намеренно нет закоммиченного `gradlew`/`gradle-wrapper.jar` (бинарник) —
> CI использует `gradle/actions/setup-gradle`. Для локальной разработки можно сгенерировать
> wrapper командой `gradle wrapper --gradle-version 8.10`.

## Установка на мобильные лаунчеры (Pojav, Zalith, FCL, Mojo и др.)

1. Скачайте `midpoint-visuals-<version>.jar` из [Releases](../../releases) или из артефактов
   последнего успешного билда в **Actions**.
2. Установите **Fabric Loader 0.16.9+** для Minecraft **1.21.4** через сам лаунчер
   (обычно: `Установить версию` → `Fabric` → выбрать `1.21.4`).
3. Скопируйте `.jar` мода, а также **Fabric API** (обязательная зависимость) и, при желании,
   **ModMenu** в папку `.minecraft/mods/` вашего профиля.
   - В Pojav/Zalith/FCL это обычно `Android/data/<пакет лаунчера>/files/.minecraft/mods/`
     или доступно через встроенный файловый менеджер лаунчера.
4. Запустите профиль Fabric 1.21.4 — в главном меню должна появиться кнопка ModMenu,
   либо просто зайдите в мир и нажмите **RSHIFT** для открытия меню Midpoint Visuals.
5. Все модули по умолчанию выключены — включите нужные через touch-friendly меню.

Меню специально сделано с крупными кнопками и без сторонних UI-библиотек — только
нативный рендер Minecraft, поэтому одинаково хорошо работает и на сенсорном экране,
и с мышью на ПК.

## Структура проекта

```
midpoint-visuals/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── src/main/java/com/midpoint/visuals/
│   ├── MidpointVisualsClient.java      # точка входа клиента
│   ├── config/                          # ModuleState, ModConfig, ConfigManager
│   ├── gui/                             # MidpointGuiScreen, MidpointKeybinds
│   ├── particle/                        # ParticleRegistry, SpiritParticle, StaticCubeParticle
│   ├── render/                          # QuantumLinkRenderer, FogBlurHandler
│   ├── cosmetics/                       # CosmeticsRenderer
│   ├── integration/                     # ModMenuApi
│   └── mixin/                           # хуки в урон/атаку/частицы/туман
├── src/main/resources/
│   ├── fabric.mod.json
│   ├── midpoint_visuals.mixins.json
│   └── assets/midpoint_visuals/...
└── .github/workflows/build.yml
```

## Лицензия

MIT — см. `fabric.mod.json`.
